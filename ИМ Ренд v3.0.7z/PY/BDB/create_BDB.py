# сдесь будут скрипты для создания БД товаров и категорий
# сначала будем
import sqlite3
import xlrd, xlwt

def shag_1():
    # Создадим базу данных категорий
    conn = sqlite3.connect('___BDB___.db')
    cur = conn.cursor()

    # Создаем таблицу в БД
    cur.execute("""CREATE TABLE IF NOT EXISTS kategorii(
           id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ,
           name_kategorii TEXT ,
           roditelskaya_kategoriya TEXT ,
           alias TEXT ,
           ssil_na_kategoriyu TEXT ,
           discription_kategorii TEXT ,
           ssilka_na_kartinku TEXT ,
           fakt_pulikacii TEXT ,
           CEO_title TEXT ,
           CEO_keywords TEXT ,
           CEO_metoopisanie TEXT ,
           kolichestvo_tovarov INTEGER);
        """)
    conn.commit()



    #открываем файл
    rb = xlrd.open_workbook('Process.xls',formatting_info=True)

    #выбираем активный лист
    sheet = rb.sheet_by_index(0)

    #получаем значение первой ячейки A1
    val = sheet.row_values(0)[0]

    #получаем список значений из всех записей
    vals = [sheet.row_values(rownum) for rownum in range(sheet.nrows)]
    for i in range(2, len(vals) ):
        #print(vals[i][0:11])
        #вставляем в БД инфу из экселя
        cur.execute("""INSERT INTO kategorii(
               name_kategorii  ,
               roditelskaya_kategoriya  ,
               alias  ,
               ssil_na_kategoriyu  ,
               discription_kategorii  ,
               ssilka_na_kartinku ,
               fakt_pulikacii ,
               CEO_title ,
               CEO_keywords ,
               CEO_metoopisanie ,
               kolichestvo_tovarov ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) """, vals[i][0:11])
        conn.commit()

    cur.execute("SELECT * FROM kategorii;")
    all_results = cur.fetchall()
    print(all_results)


def dobavlenie_stolbca():
    # Создадим/подключимся базу данных категорий
    conn = sqlite3.connect('___BDB___.db')
    cur = conn.cursor()

    # добавляем столбец со статусом от эксперта
    cur.execute("""ALTER TABLE kategorii ADD COLUMN STATUS_expert TEXT; """)
    conn.commit()

if __name__ == "__main__":

