document.addEventListener("DOMContentLoaded", () =>{
  // начинаем делать интерфейс эксперта который будет администрировать интернет магазин
  // дом загрузили теперь нужно получить джейсон со структурой категорий от сервака
  console.log('sgrg')


  // задаем в переменную цвет выбранной категории
  let cvet_vibrannoi_kategorii = 'PaleTurquoise'
  // переменная для выбранной категории
  let vibrannaya_kategoriya =''

  // переменная для массива данных 
  let dataRespone
  async function zapros() {
    let respone = await fetch ('http://127.0.0.1:5000/api/cat');
    dataRespone = await respone.json();
    make_derevo_kategorii('Каталог', ul_katalog)
  }
  

  // теперь методом рекурсии строим дерево категорий
  // самая первая категория - это каталог
  //добавляем UL
  let ul_katalog = document.createElement('span');
  ul_katalog.innerText = 'Каталог';
  

  let derevo = document.getElementById('derevo');
  derevo.append(ul_katalog);


  let n_urovnia = 1
  function make_derevo_kategorii(name_kategorii, roditel) {

    // ищем вложенные категории
    // теперь проверяем есть ли дочернии категории
    let flag_dochki = false
    let doch_kategorii = []
    for (key of dataRespone) {
      if (key.roditel === name_kategorii) {
        doch_kategorii.push(key.name);
        flag_dochki = true;
      }
    }

    // если есть вложенные категории
    if (flag_dochki) {
      // попробуем добавить + к родителю
      roditel.classList.add('minus');

      
      // если дочерние категории есть то создаем элемент <ul>
      let ul_element = document.createElement('ul');
      roditel.append(ul_element);

      // попробуем повесить обработчик событий на клик по родителю
      roditel.addEventListener('click', (event) => {
        let nam_kat
        if (roditel.innerText.indexOf('\n') > 0) {
          nam_kat = roditel.innerText.slice(0, roditel.innerText.indexOf('\n'))
        } else {
          nam_kat = roditel.innerText
        }
        let nam_event_kat
        if (event.target.innerText.indexOf('\n') > 0) {
          nam_event_kat = event.target.innerText.slice(0, event.target.innerText.indexOf('\n'))
        } else {
          nam_event_kat = event.target.innerText
        }
        //alert(nam_event_kat)

        if (nam_event_kat === nam_kat) {
          vibrannaya_kategoriya = nam_event_kat

          if (ul_element.style.display === "none") {
            ul_element.style = "display:block";
            // рисуем минус на родителе
            roditel.classList.add('minus');
            roditel.classList.remove('plus');
          } else {
            ul_element.style = "display:none";
            // рисуем минус на родителе
            roditel.classList.remove('minus');
            roditel.classList.add('plus');
          }
        }
        snyatie_cvetovogo_videleniya()

      })

      // ул и обработчик сделали теперь пробегаемся по всем дочкам и публикуем их
      for (item of doch_kategorii) {
        // поробуем проверить если эта категория со статусом НЕОБХОДИМО Удалить то пропускаем эту категорию
        let flag_status = true
        for (key of dataRespone) {
          if (key.name === item) {
            if (key.status === 'НЕОБХОДИМО УДАЛИТЬ') {
              flag_status = false
            }
          }
        }
        // если эта категория не имеет статус к удалению поэтому ее можно публиковать
        if (flag_status) {
          // создаем элемент <li>
          let li_element = document.createElement('li');
          li_element.textContent = item;

          // вешаем обработчик клика
          li_element.addEventListener('click', (event) => {
            if (event.target.innerText === li_element.innerText) {
              vibrannaya_kategoriya = event.target.innerText
            }
            snyatie_cvetovogo_videleniya()
          })

          // вешаем обработчик наведение курсора
          li_element.addEventListener('mouseover', (event) => {
            if (event.target.innerText === li_element.innerText) {
              li_element.style.background  = 'Lime';
            }
          })

          // вешаем обработчик снятия наведение курсора
          li_element.addEventListener('mouseout', (event) => {
            if (vibrannaya_kategoriya === event.target.innerText) {
              li_element.style.background  = 'PaleTurquoise';
            } else {
              li_element.style.background  = 'none';
            }
            snyatie_cvetovogo_videleniya()

          })

          // добавляем категорию в список
          ul_element.append(li_element);

          // запускаем рекурсию с этой категорией
          make_derevo_kategorii(item, li_element)
        }

      }
    }
  }


  zapros()

  // сделаем функцию которая снимает цветовое выделение с дерева категорий
  // эта функция будет отрабатывать события по выбору категории
  function snyatie_cvetovogo_videleniya() {
    let vse_kati = derevo.getElementsByTagName('li')
    for (kat of vse_kati) {
      let sravnen = ''

      if (kat.innerText.indexOf('\n') > 0) {
        sravnen = kat.innerText.slice(0, kat.innerText.indexOf('\n'))
      } else {
        sravnen = kat.innerText
      }

      if (sravnen === vibrannaya_kategoriya) {
        kat.style.background  = 'PaleTurquoise';
      } else {
        kat.style.background  = 'none';
      }
    }

    // вставляем наименование выбранной категории
    let text_vibrannoi_kategorii = document.getElementById('vibor-kat');
    text_vibrannoi_kategorii.innerText = vibrannaya_kategoriya;
  }



  // теперь делаем функционал кнопок
  // кнопка удалить категорию
  let button_remove_kategoriyu = document.getElementById('remove-kategoriyu');
  // наименование выбранной категории
  let text_vibrannoi_kategorii = document.getElementById('vibor-kat');
  vibrannaya_kategoriya = text_vibrannoi_kategorii.innerText
  // вешаем обработчик на кнопу
  button_remove_kategoriyu.addEventListener('click', (event) => {
    // проверяем чтоб вложенных категоррий не было
    let flag_dochki = false;
    for (key of dataRespone) {
      if (key.roditel === vibrannaya_kategoriya && key.status !== 'НЕОБХОДИМО УДАЛИТЬ') {
        flag_dochki = true;
      }
    }

    if (flag_dochki) {
      alert("Пока нельзя удалить категорию у которой есть дочерние категории")
      return
    }

    //присваиваем статус категории 
    for (key of dataRespone) {
      if (key.name === vibrannaya_kategoriya) {
        key.status = 'НЕОБХОДИМО УДАЛИТЬ'
      }
    }
    vibrannaya_kategoriya = ''
    // перестраиваем дерево
    ul_katalog.innerHTML = ''
    ul_katalog.innerText = 'Каталог';

    make_derevo_kategorii('Каталог', ul_katalog)

  })


  // далее пишем код для кнопки переименовать категорию
  // кнопка удалить категорию
  let button_rename_kategoriyu = document.getElementById('rename-kategoriyu');
  // вешаем обработчик на кнопу
  button_rename_kategoriyu.addEventListener('click', (event) => {
    // получаем новое наименование
    let new_name = prompt('Новое наименование категории');
    
    if (new_name !== '' && new_name !== null)  {

      //присваиваем статус категории 
      for (key of dataRespone) {
        if (key.name === vibrannaya_kategoriya) {
          key.name = new_name
        }
      }

      // далее пробегаемся вложенные категории
      for (key of dataRespone) {
        if (key.roditel === vibrannaya_kategoriya) {
          key.roditel = new_name
        }
      }

      vibrannaya_kategoriya = new_name

      // перестраиваем дерево
      ul_katalog.innerHTML = ''
      ul_katalog.innerText = 'Каталог';
      make_derevo_kategorii('Каталог', ul_katalog)
      snyatie_cvetovogo_videleniya()


    }
  })

  // вешаем обработчик на кнопку добавления вложенной категории
  let button_add_kategoriyu = document.getElementById('add-kategoriyu');
  // вешаем обработчик на кнопу
  button_add_kategoriyu.addEventListener('click', (event) => {
    // получаем новое наименование
    let new_name = prompt('Dведи наименование новой вложенной категории');
    
    if (new_name !== '' && new_name !== null)  {
      // создаем новый объект 
      new_kat ={}
      new_kat.id = ''
      new_kat.name = new_name
      new_kat.roditel = vibrannaya_kategoriya
      new_kat.status = 'НЕОБХОДИМО ДОБАВИТЬ'

      dataRespone.push(new_kat)

      vibrannaya_kategoriya = new_name

      // перестраиваем дерево
      ul_katalog.innerHTML = ''
      ul_katalog.innerText = 'Каталог';
      make_derevo_kategorii('Каталог', ul_katalog)
      snyatie_cvetovogo_videleniya()


    }
  })




















})