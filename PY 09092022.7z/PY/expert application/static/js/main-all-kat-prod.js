document.addEventListener("DOMContentLoaded", () =>{
  // начинаем делать интерфейс эксперта который будет администрировать интернет магазин
  // дом загрузили теперь нужно получить джейсон со структурой категорий от сервака
  console.log('sgrg');


  // задаем в переменную цвет выбранной категории
  let cvet_vibrannoi_kategorii = 'PaleTurquoise';
  // переменная для выбранной категории
  let vibrannaya_kategoriya ='';

  // переменная для массива данных 
  let dataRespone
  async function zapros() {
    let respone = await fetch ('http://127.0.0.1:5000/api/cat');
    dataRespone = await respone.json();
    make_derevo_kategorii('Каталог', ul_katalog);
  }
  

  // теперь методом рекурсии строим дерево категорий
  // самая первая категория - это каталог
  //добавляем UL
  let ul_katalog = document.createElement('span');
  ul_katalog.innerText = 'Каталог';
  

  let derevo = document.getElementById('derevo');
  derevo.append(ul_katalog);


  let n_urovnia = 1
  function make_derevo_kategorii(name_kategorii, roditel) {

    // ищем вложенные категории
    // теперь проверяем есть ли дочернии категории
    let flag_dochki = false
    let doch_kategorii = []
    for (key of dataRespone) {
      if (key.roditel === name_kategorii) {
        doch_kategorii.push(key.name);
        flag_dochki = true;
      }
    }

    // если есть вложенные категории
    if (flag_dochki) {
      // попробуем добавить + к родителю
      roditel.classList.add('minus');

      
      // если дочерние категории есть то создаем элемент <ul>
      let ul_element = document.createElement('ul');
      roditel.append(ul_element);

      // попробуем повесить обработчик событий на клик по родителю
      roditel.addEventListener('click', (event) => {
        let nam_kat
        if (roditel.innerText.indexOf('\n') > 0) {
          nam_kat = roditel.innerText.slice(0, roditel.innerText.indexOf('\n'))
        } else {
          nam_kat = roditel.innerText
        }
        let nam_event_kat
        if (event.target.innerText.indexOf('\n') > 0) {
          nam_event_kat = event.target.innerText.slice(0, event.target.innerText.indexOf('\n'))
        } else {
          nam_event_kat = event.target.innerText
        }
        //alert(nam_event_kat)

        if (nam_event_kat === nam_kat) {
          vibrannaya_kategoriya = nam_event_kat

          if (ul_element.style.display === "none") {
            ul_element.style = "display:block";
            // рисуем минус на родителе
            roditel.classList.add('minus');
            roditel.classList.remove('plus');
          } else {
            ul_element.style = "display:none";
            // рисуем минус на родителе
            roditel.classList.remove('minus');
            roditel.classList.add('plus');
          }
        }
        snyatie_cvetovogo_videleniya()

      })

      // ул и обработчик сделали теперь пробегаемся по всем дочкам и публикуем их
      for (item of doch_kategorii) {
        // поробуем проверить если эта категория со статусом НЕОБХОДИМО Удалить то пропускаем эту категорию
        let flag_status = true
        for (key of dataRespone) {
          if (key.name === item) {
            if (key.status === 'НЕОБХОДИМО УДАЛИТЬ') {
              flag_status = false
            }
          }
        }
        // если эта категория не имеет статус к удалению поэтому ее можно публиковать
        if (flag_status) {
          // создаем элемент <li>
          let li_element = document.createElement('li');
          li_element.textContent = item;

          // вешаем обработчик клика
          li_element.addEventListener('click', (event) => {
            if (event.target.innerText === li_element.innerText) {
              vibrannaya_kategoriya = event.target.innerText
            }
            snyatie_cvetovogo_videleniya()
          })

          // вешаем обработчик наведение курсора
          li_element.addEventListener('mouseover', (event) => {
            if (event.target.innerText === li_element.innerText) {
              li_element.style.background  = 'Lime';
            }
          })

          // вешаем обработчик снятия наведение курсора
          li_element.addEventListener('mouseout', (event) => {
            if (vibrannaya_kategoriya === event.target.innerText) {
              li_element.style.background  = 'PaleTurquoise';
            } else {
              li_element.style.background  = 'none';
            }
            snyatie_cvetovogo_videleniya()

          })

          // добавляем категорию в список
          ul_element.append(li_element);

          // запускаем рекурсию с этой категорией
          make_derevo_kategorii(item, li_element)
        }

      }
    }
  }


  zapros()

  // сделаем функцию которая снимает цветовое выделение с дерева категорий
  // эта функция будет отрабатывать события по выбору категории
  function snyatie_cvetovogo_videleniya() {
    let vse_kati = derevo.getElementsByTagName('li')
    for (kat of vse_kati) {
      let sravnen = ''

      if (kat.innerText.indexOf('\n') > 0) {
        sravnen = kat.innerText.slice(0, kat.innerText.indexOf('\n'))
      } else {
        sravnen = kat.innerText
      }

      if (sravnen === vibrannaya_kategoriya) {
        kat.style.background  = 'PaleTurquoise';
      } else {
        kat.style.background  = 'none';
      }
    }

    // вставляем наименование выбранной категории
    let text_vibrannoi_kategorii = document.getElementById('vibor-kat');
    text_vibrannoi_kategorii.innerText = vibrannaya_kategoriya;
    span_roditelskaya_new_kat.textContent = vibrannaya_kategoriya

  }



  // теперь делаем функционал кнопок
  // кнопка удалить категорию
  let button_remove_kategoriyu = document.getElementById('remove-kategoriyu');
  // наименование выбранной категории
  let text_vibrannoi_kategorii = document.getElementById('vibor-kat');
  vibrannaya_kategoriya = text_vibrannoi_kategorii.innerText;
  // вешаем обработчик на кнопу
  button_remove_kategoriyu.addEventListener('click', (event) => {
    if (vibrannaya_kategoriya == '')  {
      return
    }
    // проверяем чтоб вложенных категоррий не было
    let flag_dochki = false;
    for (key of dataRespone) {
      if (key.roditel === vibrannaya_kategoriya && key.status !== 'НЕОБХОДИМО УДАЛИТЬ') {
        flag_dochki = true;
      }
    }

    if (flag_dochki) {
      alert("Пока нельзя удалить категорию у которой есть дочерние категории")
      return
    }

    //присваиваем статус категории 
    for (key of dataRespone) {
      if (key.name === vibrannaya_kategoriya) {
        key.status = 'НЕОБХОДИМО УДАЛИТЬ'
      }
    }
    vibrannaya_kategoriya = ''
    // перестраиваем дерево
    ul_katalog.innerHTML = ''
    ul_katalog.innerText = 'Каталог';

    make_derevo_kategorii('Каталог', ul_katalog)

  })


  // далее пишем код для кнопки переименовать категорию
  // кнопка удалить категорию
  let button_rename_kategoriyu = document.getElementById('rename-kategoriyu');
  // вешаем обработчик на кнопу
  button_rename_kategoriyu.addEventListener('click', (event) => {
    // получаем новое наименование
    if (vibrannaya_kategoriya == '')  {
      return
    }
    let new_name = prompt('Новое наименование категории');
    
    if (new_name !== '' && new_name !== null)  {

      //присваиваем статус категории 
      for (key of dataRespone) {
        if (key.name === vibrannaya_kategoriya) {
          key.name = new_name
        }
      }

      // далее пробегаемся вложенные категории
      for (key of dataRespone) {
        if (key.roditel === vibrannaya_kategoriya) {
          key.roditel = new_name
        }
      }

      vibrannaya_kategoriya = new_name

      // перестраиваем дерево
      ul_katalog.innerHTML = ''
      ul_katalog.innerText = 'Каталог';
      make_derevo_kategorii('Каталог', ul_katalog)
      snyatie_cvetovogo_videleniya()


    }
  })

  // вешаем обработчик на кнопку добавления вложенной категории
  let button_add_kategoriyu = document.getElementById('add-kategoriyu');
  // вешаем обработчик на кнопу
  button_add_kategoriyu.addEventListener('click', (event) => {
    if (vibrannaya_kategoriya !== '')  {
      
      // получаем новое наименование
      let new_name = prompt('Dведи наименование новой вложенной категории');
      
      if (new_name !== '' && new_name !== null)  {
        // создаем новый объект 
        new_kat ={}
        new_kat.id = ''
        new_kat.name = new_name
        new_kat.roditel = vibrannaya_kategoriya
        new_kat.status = 'НЕОБХОДИМО ДОБАВИТЬ'

        dataRespone.push(new_kat)

        vibrannaya_kategoriya = new_name

        // перестраиваем дерево
        ul_katalog.innerHTML = ''
        ul_katalog.innerText = 'Каталог';
        make_derevo_kategorii('Каталог', ul_katalog)
        snyatie_cvetovogo_videleniya()
      }
    }
  })





  //* теперь скачиваем биг массив по всем товарам
  // переменная для массива данных 
  let dataRespone_all_products
  async function zapros_products() {
    let respone = await fetch ('http://127.0.0.1:5000/api/all_products');
    dataRespone_all_products = await respone.json();
    make_derevo_new_kategorii(dataRespone_all_products);
  }

  // по аналогии с деревом категорий строим структуру новых категорий
  // переменная выбранной категории из числа новых
  let vibrannaya_new_kategoriya ='';
  
  // элемент выбранной новой категории
  let span_vibrannaya_new_kat = document.getElementById('vibor-new-kat');

  // элемент родительской категории для выбранной новой категории
  let span_roditelskaya_new_kat = document.getElementById('vibor-new-kat-rod');

  //добавляем UL
  let new_katalog = document.createElement('span');
  new_katalog.innerText = 'Каталог новых категорий:';
  
  // вставляем заголовок в див
  let new_derevo = document.getElementById('new-derevo');
  new_derevo.append(new_katalog);

  // функция которая строит дерево новых категорий
  function make_derevo_new_kategorii(dataRespone_products) {

    // на вход мы получаем массив с объектами товаров
    // массив с новыми категориями
    let new_kat = [];

    //теперь перебираем новые категории и добамляем в масси
    for (key of dataRespone_products) {
      flag_new = false
      for (new_k of new_kat) {
        if (key.provider_kategoriya_tovara === new_k) {
          flag_new = true;
        }
      }

      if (!flag_new && key.product_status_expert === 'НЕОБХОДИМО ОПРЕДЕЛИТЬ КАТЕГОРИЮ ТОВАРА') {
        new_kat.push(key.provider_kategoriya_tovara);
      }

    }
    // если новые категории есть то добавляем элемент гд
    
    if (new_kat.length > 0) {
      let ul_new_katalog = document.createElement('ul');
      new_katalog.append(ul_new_katalog);
    
      // теперь строим дерево новых категорий в элемент ul_new_katalog
      for (new_k of new_kat) {
        // добавляем элемент li
        let li_new_element = document.createElement('li');
        li_new_element.textContent = new_k;

        // добавляем стили для новой категории
        li_new_element.classList.add('new_cat');

        // теперь вешаем обработчик для перетаскивания новой категории
        // короч с перетаскиванием пока не получилось((( Будем делать по классике - статичный интерфейс
        li_new_element.addEventListener('click', (event) => {
          vibrannaya_new_kategoriya =''
          let nam_kat
          if (li_new_element.innerText.indexOf('\n') > 0) {
            nam_kat = li_new_element.innerText.slice(0, li_new_element.innerText.indexOf('\n'))
          } else {
            nam_kat = li_new_element.innerText
          }
          let nam_event_kat
          if (event.target.innerText.indexOf('\n') > 0) {
            nam_event_kat = event.target.innerText.slice(0, event.target.innerText.indexOf('\n'))
          } else {
            nam_event_kat = event.target.innerText
          }
          //alert(nam_event_kat)

          if (nam_event_kat === nam_kat) {
            vibrannaya_new_kategoriya = nam_event_kat
            span_vibrannaya_new_kat.textContent = vibrannaya_new_kategoriya
            span_roditelskaya_new_kat.textContent = text_vibrannoi_kategorii.textContent
          }
  
        })



        ul_new_katalog.append(li_new_element);

        // создаем элемент ul для вложенныъ товаров
        let ul_new_prod = document.createElement('ul');
        li_new_element.append(ul_new_prod)
        // теперь добавляем товары в каждую новую категорию
        for (item of dataRespone_products) {
          if (item.provider_kategoriya_tovara === new_k) {
            //а вот тепрь добавляем товар
            let li_new_element_produkt = document.createElement('li');
            // создаем элемент спан для названия товара
            

            // добавляем картинку
            let img = document.createElement('img');
            img.src = "";
            img.width="189px";
            img.height="255px";
            img.alt="alt";
            li_new_element_produkt.append(img);

            // добавляем название товара
            let name_tovar = document.createElement('span');
            name_tovar.textContent = item.provider_nazvanie_tovara;
            li_new_element_produkt.append(name_tovar);
            ul_new_prod.append(li_new_element_produkt);
          }
        }
      }
    }
  }


  zapros_products()

  // вешаем обработчик на кнопку добавления родительской категории
  let button_add_rod_kategoriyu = document.getElementById('add-rod-kategoriyu');
  // вешаем обработчик на кнопу
  button_add_rod_kategoriyu.addEventListener('click', (event) => {
    if (span_vibrannaya_new_kat.textContent != '' && span_roditelskaya_new_kat.textContent != '') {
      // отрабатываем товары в списке новых
      for (key of dataRespone_products) {
        if (key.provider_kategoriya_tovara === vibrannaya_new_kategoriya) {
          // нашли товар, теперь нужно в массиве 
          key.product_kategoriya_tovara = span_roditelskaya_new_kat.textContent;
          key.product_status_expert = 'КАТЕГОРИЯ ОПРЕДЕЛЕНА';
          new_katalog.innerHTML ='';
          make_derevo_new_kategorii(dataRespone_products);
          span_vibrannaya_new_kat.textContent = '';
          vibrannaya_new_kategoriya = '';
          //span_roditelskaya_new_kat.textContent = '';
        }
      }
    }
  })

  // отрабатываем кнопку отправки конфигурации на сервер



})