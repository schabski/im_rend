from flask import Flask, jsonify, render_template
import sqlite3



app = Flask(__name__)
#from app import views


@app.route('/')
@app.route('/index')
def index():
    return render_template("index.html")

@app.route('/api/cat', methods=['GET'])
def get_tasks():
    # подключаем БД
    conn = sqlite3.connect(r'./../../BDB/___BDB___.db')
    cur = conn.cursor()
    # нужно обратиться к БДБ и создать список словаре который потом улетит в бэк
    cur.execute("SELECT id, name_kategorii, roditelskaya_kategoriya, STATUS_expert FROM kategorii;")
    all_results = cur.fetchall()
    #DATA=[]

    DATA = [{'id': all_results[i][0],'name': all_results[i][1], 'roditel': all_results[i][2], 'status': all_results[i][3]} for i in range(len(all_results))]

    return jsonify(DATA)



if __name__ == "__main__":
    app.run(debug=True)