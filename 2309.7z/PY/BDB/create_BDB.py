# сдесь будут скрипты для создания БД товаров и категорий
# сначала будем
import sqlite3
import xlrd, xlwt

def shag_1():
    # Создадим базу данных категорий
    conn = sqlite3.connect('___BDB___.db')
    cur = conn.cursor()

    # Создаем таблицу в БД
    cur.execute("""CREATE TABLE IF NOT EXISTS kategorii(
           id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ,
           name_kategorii TEXT ,
           roditelskaya_kategoriya TEXT ,
           alias TEXT ,
           ssil_na_kategoriyu TEXT ,
           discription_kategorii TEXT ,
           ssilka_na_kartinku TEXT ,
           fakt_pulikacii TEXT ,
           CEO_title TEXT ,
           CEO_keywords TEXT ,
           CEO_metoopisanie TEXT ,
           kolichestvo_tovarov INTEGER);
        """)
    conn.commit()



    #открываем файл
    rb = xlrd.open_workbook('Process.xls',formatting_info=True)

    #выбираем активный лист
    sheet = rb.sheet_by_index(0)

    #получаем значение первой ячейки A1
    val = sheet.row_values(0)[0]

    #получаем список значений из всех записей
    vals = [sheet.row_values(rownum) for rownum in range(sheet.nrows)]
    for i in range(2, len(vals) ):
        #print(vals[i][0:11])
        #вставляем в БД инфу из экселя
        cur.execute("""INSERT INTO kategorii(
               name_kategorii  ,
               roditelskaya_kategoriya  ,
               alias  ,
               ssil_na_kategoriyu  ,
               discription_kategorii  ,
               ssilka_na_kartinku ,
               fakt_pulikacii ,
               CEO_title ,
               CEO_keywords ,
               CEO_metoopisanie ,
               kolichestvo_tovarov ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) """, vals[i][0:11])
        conn.commit()

    cur.execute("SELECT * FROM kategorii;")
    all_results = cur.fetchall()
    print(all_results)


def dobavlenie_stolbca():
    # Создадим/подключимся базу данных категорий
    conn = sqlite3.connect('___BDB___.db')
    cur = conn.cursor()

    # добавляем столбец со статусом от эксперта
    cur.execute("""ALTER TABLE products ADD COLUMN STATUS_parsing TEXT; """)
    conn.commit()
    
    
def formirovanie_tablici_s_tovarami():
    # Создадим базу данных категорий
    conn = sqlite3.connect('___BDB___.db')
    cur = conn.cursor()

    # Создаем таблицу в БД
    cur.execute("""CREATE TABLE IF NOT EXISTS products(
           id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ,
           product_nazvanie_tovara TEXT ,
           product_opisanie_tovara TEXT ,
           product_kategoriya_tovara TEXT ,
           product_cena_tovara TEXT ,
           product_nalichie_tovara TEXT ,
           product_artikul_tovara TEXT ,
           product_kartinki_tovara TEXT ,
           product_dokumenti_tovara TEXT ,
           product_status_expert TEXT ,
           product_garantiya_na_tovar TEXT ,
           provider_name TEXT ,
           provider_ssilka_na_tovar TEXT , 
           provider_nazvanie_tovara TEXT ,
           provider_opisanie_tovara TEXT ,
           provider_kategoriya_tovara TEXT ,
           provider_cena_tovara TEXT ,
           provider_nalichie_tovara TEXT ,
           provider_artikul_tovara TEXT ,
           provider_kartinki_tovara TEXT ,
           provider_dokumenti_tovara TEXT ,
           provider_status_tovara_dla_BDB TEXT ,
           provider_garantiya_na_tovar TEXT,
           site_ssilka_na_tovar TEXT ,
           site_ssilka_na_doc TEXT ,
           site_ssilka_na_img TEXT ,
           site_fakt_publikacii TEXT ,
           site_zagolovok_stranici TEXT ,
           site_metoooisanie TEXT ,
           site_keywords TEXT);
        """)
    conn.commit()

    kort = ('', '', '', '', '', '', '', '', '', '', 'test company', 'test TEXT', 'test TEXT', 'test TEXT', 'test TEXT', 'test TEXT', 'test TEXT', 'test TEXT', 'test TEXT', 'test TEXT', 'test TEXT', '1 год', '', '', '', '', '', '', '')

    #вставляем в БД инфу о тестовом товаре
    cur.execute("""INSERT INTO products(
           product_nazvanie_tovara  ,
           product_opisanie_tovara  ,
           product_kategoriya_tovara  ,
           product_cena_tovara  ,
           product_nalichie_tovara  ,
           product_artikul_tovara  ,
           product_kartinki_tovara  ,
           product_dokumenti_tovara  ,
           product_status_expert  ,
           product_garantiya_na_tovar  ,
           provider_name  ,
           provider_ssilka_na_tovar  , 
           provider_nazvanie_tovara  ,
           provider_opisanie_tovara  ,
           provider_kategoriya_tovara  ,
           provider_cena_tovara  ,
           provider_nalichie_tovara  ,
           provider_artikul_tovara  ,
           provider_kartinki_tovara  ,
           provider_dokumenti_tovara  ,
           provider_status_tovara_dla_BDB  ,
           provider_garantiya_na_tovar ,
           site_ssilka_na_tovar  ,
           site_ssilka_na_doc  ,
           site_ssilka_na_img  ,
           site_fakt_publikacii  ,
           site_zagolovok_stranici  ,
           site_metoooisanie  ,
           site_keywords) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)  """, kort)
    conn.commit()

    cur.execute("SELECT * FROM products;")
    all_results = cur.fetchall()
    print(all_results)    
    
    

if __name__ == "__main__":
    print('dfz')
    dobavlenie_stolbca()
