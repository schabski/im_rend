# Здесь я попробую написать код для парсинга сайтов поставщиков

import requests
from bs4 import BeautifulSoup
import sqlite3
import os.path
import json


#Выделяем все по функциям
def voll_kat_1_urovnia():
    print("Поехали. Собираем категории 1 уровня ВОЛЛ")


    # Создаем таблицу в БД
    cur.execute("""CREATE TABLE IF NOT EXISTS voll_kategorii_1(
           name_kategorii TEXT ,
           ssil_kategorii TEXT);
        """)
    conn.commit()

    # делаем запрос на сайт
    url = r'https://voll.ru/product'
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'lxml')
    quotes = soup.find_all('li', class_='child')

    for link in quotes:
        # print(link)

        ss = link.find_all('a', class_='')

        ss2 = r'https://voll.ru' + ss[0]['href']

        # проверяем есть ли такая категория в таблице
        cur.execute("SELECT * FROM voll_kategorii_1 WHERE ssil_kategorii  = ?", (ss2,))
        if cur.fetchone() is None:
            # если категории раньше не было
            cur.execute("""INSERT INTO voll_kategorii_1 VALUES(?, ?);""", (link.text.replace(chr(10), ''), ss2))
            conn.commit()

def voll_kat_2_urovnia():
    print("Поехали. Собираем категории 2 уровня ВОЛЛ")

    # Создаем таблицу в БД
    cur.execute("""CREATE TABLE IF NOT EXISTS voll_kategorii_2(
           name_kategorii_2 TEXT ,
           ssil_kategorii_2 TEXT);
        """)
    conn.commit()

    #нужно перебрать все категории 1 уровня и найти в них ссылки на категории 2 уровня

    #Все категории 1 уровня
    cur.execute("SELECT ssil_kategorii FROM voll_kategorii_1;")
    all_kategorii_1_urovnia = cur.fetchall()

    for item in all_kategorii_1_urovnia:
        #теперь загружаем каждую категорию 1 уровня
        kat_2_ssil = item[0]

        # делаем запрос на сайт
        url = kat_2_ssil
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'lxml')

        # страницу загрузили - дальше ищем теги
        quotes = soup.find_all('div', class_='title')
        #print(quotes)

        for link in quotes:
            # print(link)

            ss = link.find_all('a', class_='dark-color')

            if len(ss) > 0:
                ss2 = r'https://voll.ru' + ss[0]['href']
                print(ss2)
                # проверяем есть ли такая категория в таблице
                cur.execute("SELECT * FROM voll_kategorii_2 WHERE ssil_kategorii_2  = ?", (ss2,))

                # получаем наименование категории
                name_kat = link.text.replace(chr(10), '')
                name_kat = name_kat.strip()
                if cur.fetchone() is None:
                    # если категории раньше не было
                    cur.execute("""INSERT INTO voll_kategorii_2 VALUES(?, ?);""", (name_kat, ss2))
                    conn.commit()

def voll_tovari():
    print("Поехали. Собираем товары ВОЛЛ")
    # нужно занрузить категории 1 и второго уровня и найти все ссылки на товары
    # Создаем стобцы в БД
    cur.execute("""CREATE TABLE IF NOT EXISTS voll_ssil_prod(
           ssilka_na_tovar TEXT);
        """)
    conn.commit()

    # ссылки на категории 1 уровня
    #Все категории 1 уровня
    cur.execute("SELECT ssil_kategorii FROM voll_kategorii_1;")
    all_kategorii_1_urovnia = cur.fetchall()

    #Все категории 2 уровня
    cur.execute("SELECT ssil_kategorii_2 FROM voll_kategorii_2;")
    all_kategorii_2_urovnia = cur.fetchall()

    # вообще все категории
    all_kat =all_kategorii_1_urovnia + all_kategorii_2_urovnia
    #перебираем все категории и ищем ссылки на товары
    for item in all_kat:
        #теперь загружаем каждую категорию
        kat_ssil = item[0]

        # делаем запрос на сайт
        url = kat_ssil
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'lxml')

        # страницу загрузили - дальше ищем теги
        quotes = soup.find_all('div', class_='title')

        for link in quotes:
            # print(link)

            ss = link.find_all('a', class_='dark-color')


            if len(ss) > 0:
                ss2 = r'https://voll.ru' + ss[0]['href']
                print(ss2)
                # проверяем есть ли такая категория в таблице
                cur.execute("SELECT * FROM voll_ssil_prod WHERE ssilka_na_tovar  = ?", (ss2,))
                if cur.fetchone() is None:
                    # если категории раньше не было
                    cur.execute("""INSERT INTO voll_ssil_prod VALUES(?);""", (ss2,))
                    conn.commit()

def voll_dannie_o_tovarah():
    print('Теперь собираем инфу о товарах')
    # сдесь скачиваем данные о товарах
    # создаем таблицу с товарами
    cur.execute("""CREATE TABLE IF NOT EXISTS voll_tovari(
           ssilka_na_tovar TEXT ,
           nazvanie_tovara TEXT ,
           opisanie_tovara TEXT ,
           kategoriya_tovara TEXT ,
           cena_tovara TEXT ,
           nalichie_tovara TEXT ,
           artikul_tovara TEXT ,
           kartinki_tovara TEXT ,
           dokumenti_tovara TEXT ,
           status_tovara_dla_BDB TEXT ,
           garantiya_na_tovar TEXT);
        """)
    conn.commit()


    # получаем список ссылок на товары
    cur.execute("SELECT * FROM voll_ssil_prod;")
    all_ssil_tovari = cur.fetchall()
    for item in all_ssil_tovari:
        print('Ссылка на товар', item)
        #теперь загружаем каждую категорию
        tovar_ssil = item[0]
        # делаем запрос на сайт
        url = tovar_ssil
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'lxml')

        # страницу загрузили - дальше ищем теги
        # ищем название товара
        print('Название товара', soup.find_all('h1', id='pagetitle'))
        if len(soup.find_all('h1', id='pagetitle'))>0:
            name_tovara = soup.find('h1', id='pagetitle').text

            # получаем артикул товара
            art = soup.find('div', class_='article')
            if art != None:

                artikul = str(art.find('span', class_='').text)

                # считываем описание товара
                # сначало описание
                opisanie_tovara = ''
                if len(soup.find_all('div', class_='content')) > 0:
                    opisanie_tovara = str(soup.find_all('div', class_='content')[0])
                    # характеристики
                    if len(soup.find_all('div', class_='char-wrapp')) > 0:
                        opisanie_tovara += str(soup.find_all('div', class_='char-wrapp')[0])
                if opisanie_tovara == None:
                    opisanie_tovara = str('Описания пока нет')

                # полуаем категорию товара

                all_bk = soup.find_all('ul', class_='breadcrumb')[0]
                kat_list = all_bk.find_all('li')
                kategoriya_1 = kat_list[-2].text

                # получаем  цену товара
                cena_tovara = soup.find_all('span', class_='price_val')[0].text

                # получаем наличие товара
                nalichie_tovara = str(soup.find('div', class_='status-icon instock'))



                # получаем список картинок
                kartinki = soup.find_all('li', class_='bx-viewport')

                kartinki_tovara = json.dumps([r'https://voll.ru' + kartinki[i]['src'] for i in range(len(kartinki))])

                # получаем список документов
                # находим документы
                doki = soup.find('div', class_='title-tab-heading visible-xs')
                if doki != None:
                    # находим все ссылки

                    doki_2 = doki.find_all('a', class_='dark-color text')
                    dokumenti_tovara = json.dumps([r'https://voll.ru' + doki_2[i]['href'] for i in range(len(doki_2))])
                else:
                    dokumenti_tovara =''

                #статус товара
                status_tovara = 'В процессе парсинга'

                #получаем срок гарантии на товар
                garantiya_na_tovar = soup.find('a', class_='garanty-link')
                if garantiya_na_tovar != None:
                    garantiya_na_tovar = garantiya_na_tovar.text
                else:
                    garantiya_na_tovar = ''

                # все данные о товаре считали
                print((tovar_ssil,
                     name_tovara,
                     opisanie_tovara,
                     kategoriya_1,
                     cena_tovara,
                     nalichie_tovara,
                     artikul,
                     kartinki_tovara,
                     dokumenti_tovara,
                     status_tovara,
                     garantiya_na_tovar))

                print((type(tovar_ssil),
                     type(name_tovara),
                     type(opisanie_tovara),
                     type(kategoriya_1),
                     type(cena_tovara),
                     type(nalichie_tovara),
                     type(artikul),
                     type(kartinki_tovara),
                     type(dokumenti_tovara),
                     type(status_tovara),
                     type(garantiya_na_tovar)))
                # проверяем есть ли такой товар в БД в таблице
                cur.execute("SELECT artikul_tovara FROM voll_tovari WHERE artikul_tovara  = ?", (artikul,))
                if cur.fetchone() is None:
                    # если товара нет раньше то добавляем его в БД
                    cur.execute("""INSERT INTO voll_tovari(
                    ssilka_na_tovar ,
                   nazvanie_tovara ,
                   opisanie_tovara ,
                   kategoriya_tovara ,
                   cena_tovara ,
                   nalichie_tovara ,
                   artikul_tovara ,
                   kartinki_tovara ,
                   dokumenti_tovara ,
                   status_tovara_dla_BDB ,
                   garantiya_na_tovar) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (tovar_ssil,
                     name_tovara,
                     opisanie_tovara,
                     kategoriya_1,
                     cena_tovara,
                     nalichie_tovara,
                     artikul,
                     kartinki_tovara,
                     dokumenti_tovara,
                     status_tovara,
                     garantiya_na_tovar))
                    conn.commit()

def voll_vnesenie_v_BDB():
    # Создадим/подключимся базу данных BDB
    conn_BDB = sqlite3.connect('___BDB___.db')
    cur_BDB = conn_BDB.cursor()
    
    # в существуюЩих в БДБ товарах от VOLL проставляем статус, что вноится инфа из парсинга
    cur_BDB.execute("""Update products set STATUS_parsing = ВНОСИТСЯ_ИНФА_ИЗ_ПАРСИНГА where provider_name = VOLL""")
    conn_BDB.commit()
        
    # ДАЛЕЕ НУЖНО считать все товары из БД парсинга и внести в БДБ
    cur.execute("""SELECT ssilka_na_tovar ,
                nazvanie_tovara ,
                opisanie_tovara ,
                kategoriya_tovara ,
                cena_tovara ,
                nalichie_tovara ,
                artikul_tovara ,
                kartinki_tovara ,
                dokumenti_tovara ,
                status_tovara_dla_BDB ,
                garantiya_na_tovar FROM voll_tovari;""")
    all_tovari = cur.fetchall()
    
    # перебираем все товары. Нужно внести инфу в БДБ и проставить статусы
    for item in all_tovari:
        # ссылка на товар
        provider_ssilka_na_tovar = item[0]
        
        # название товара
        provider_nazvanie_tovara = item[1]
        
        # артикул товара
        artikul_tovara = item[6]
        
        # проверяем есть ли такой товар в БДБ
        cur_BDB.execute("SELECT provider_artikul_tovara FROM products WHERE where provider_name = VOLL, provider_artikul_tovara  = ?", (artikul_tovara,))
        if cur_BDB.fetchone() is None:
            # если такого товара нет то ... добавляем товар в БДБ
            kort = ('',     # product_nazvanie_tovara
                    '',     # product_opisanie_tovara
                    '',     # product_kategoriya_tovara
                    '',     # product_cena_tovara
                    '',     # product_nalichie_tovara
                    '',     # product_artikul_tovara
                    '',     # product_kartinki_tovara
                    '',     # product_dokumenti_tovara
                    '',     # product_status_expert
                    '',     # product_garantiya_na_tovar
                    'VOLL',     # provider_name
                    'test TEXT',     # provider_ssilka_na_tovar
                    'test TEXT',     # provider_nazvanie_tovara
                    'test TEXT',     # provider_opisanie_tovara
                    'test TEXT',     # provider_kategoriya_tovara
                    'test TEXT',     # provider_cena_tovara
                    'test TEXT',     # provider_nalichie_tovara
                    'test TEXT',     # provider_artikul_tovara
                    'test TEXT',     # provider_kartinki_tovara
                    'test TEXT',     # provider_dokumenti_tovara
                    'test TEXT',     # provider_status_tovara_dla_BDB
                    '1 год',     # provider_garantiya_na_tovar
                    '',     # site_ssilka_na_tovar
                    '',     # site_ssilka_na_doc
                    '',     # site_ssilka_na_img
                    '',     # site_fakt_publikacii
                    '',     # site_zagolovok_stranici
                    '',     # site_metoooisanie
                    '',     # site_keywords
                    '')     # STATUS_parsing
        
            #вставляем в БД инфу о тестовом товаре
            cur_BDB.execute("""INSERT INTO products(
                   product_nazvanie_tovara  ,
                   product_opisanie_tovara  ,
                   product_kategoriya_tovara  ,
                   product_cena_tovara  ,
                   product_nalichie_tovara  ,
                   product_artikul_tovara  ,
                   product_kartinki_tovara  ,
                   product_dokumenti_tovara  ,
                   product_status_expert  ,
                   product_garantiya_na_tovar  ,
                   provider_name  ,
                   provider_ssilka_na_tovar  , 
                   provider_nazvanie_tovara  ,
                   provider_opisanie_tovara  ,
                   provider_kategoriya_tovara  ,
                   provider_cena_tovara  ,
                   provider_nalichie_tovara  ,
                   provider_artikul_tovara  ,
                   provider_kartinki_tovara  ,
                   provider_dokumenti_tovara  ,
                   provider_status_tovara_dla_BDB  ,
                   provider_garantiya_na_tovar ,
                   site_ssilka_na_tovar  ,
                   site_ssilka_na_doc  ,
                   site_ssilka_na_img  ,
                   site_fakt_publikacii  ,
                   site_zagolovok_stranici  ,
                   site_metoooisanie  ,
                   site_keywords,
                   STATUS_parsing) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)  """, kort)
            conn_BDB.commit()
    
if __name__ == "__main__":
    os.remove('bd_parser.db')
    # Создадим базу данных категорий 1 уровня
    conn = sqlite3.connect('bd_parser.db')
    cur = conn.cursor()


    #запускаем сбор категорий первого уровня
    voll_kat_1_urovnia()

    #запускаем сбор категорий второго уровня
    voll_kat_2_urovnia()

    # теперь пришло время скачать инфу о товарах. Это самое трудное
    # получаем таблицу со всеми товарами
    voll_tovari()

    # теперь загружаем страничку каждого товара и скачиваем данные о товаре
    voll_dannie_o_tovarah()

    # теперь вносим инфу от парсинга в биг базу данных

