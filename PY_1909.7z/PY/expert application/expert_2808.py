from flask import Flask, jsonify, render_template, make_response, url_for, request
import sqlite3
import os.path


app = Flask(__name__)
#from app import views


@app.route('/')
@app.route('/index')
def index():
    response = make_response(render_template('index.html'))
    response.headers['Access-Control-Allow-Origin'] = '*'
    return response
    #return render_template("index.html")

@app.route('/api/cat', methods=['GET'])
def get_tasks():
    # подключаем БД
    conn = sqlite3.connect(r'./../BDB/___BDB___.db')
    cur = conn.cursor()
    # нужно обратиться к БДБ и создать список словаре который потом улетит во френт
    cur.execute("SELECT id, name_kategorii, roditelskaya_kategoriya, STATUS_expert FROM kategorii;")
    all_results = cur.fetchall()
    #DATA=[]

    DATA = [{'id': all_results[i][0],'name': all_results[i][1], 'roditel': all_results[i][2], 'status': all_results[i][3]} for i in range(len(all_results))]
    
    response = make_response(jsonify(DATA))
    response.headers['Access-Control-Allow-Origin'] = '*'
    return response
    #return jsonify(DATA)

# пишим энд поинт для АПИ новых товаров
@app.route('/api/new_products', methods=['GET'])
def get_tasks_products():
    # подключаем БД
    conn = sqlite3.connect(r'./../BDB/___BDB___.db')
    cur = conn.cursor()
    # нужно обратиться к БДБ и создать список словаре который потом улетит во френт
    cur.execute("""SELECT id, 
                product_nazvanie_tovara  ,
                product_kategoriya_tovara  ,
                product_artikul_tovara  ,
                product_kartinki_tovara  ,
                product_dokumenti_tovara  ,
                product_status_expert  ,
                provider_name  ,
                provider_ssilka_na_tovar  , 
                provider_nazvanie_tovara  ,
                provider_kategoriya_tovara  ,
                provider_cena_tovara  ,
                provider_nalichie_tovara  ,
                provider_artikul_tovara FROM products WHERE product_status_expert='НЕОБХОДИМО ОПРЕДЕЛИТЬ КАТЕГОРИЮ ТОВАРА';""")
    all_results = cur.fetchall()
    #DATA=[]

    DATA_products = [{'id': all_results[i][0],
             'product_nazvanie_tovara': all_results[i][1], 
             'product_kategoriya_tovara': all_results[i][2], 
             'product_artikul_tovara': all_results[i][3], 
             'product_kartinki_tovara': all_results[i][4], 
             'product_dokumenti_tovara': all_results[i][5], 
             'product_status_expert': all_results[i][6], 
             'provider_name': all_results[i][7], 
             'provider_ssilka_na_tovar': all_results[i][8], 
             'provider_nazvanie_tovara': all_results[i][9], 
             'provider_kategoriya_tovara': all_results[i][10], 
             'provider_cena_tovara': all_results[i][11], 
             'provider_nalichie_tovara': all_results[i][12], 
             'provider_artikul_tovara': all_results[i][13]} for i in range(len(all_results))]
    response = make_response(jsonify(DATA_products))
    response.headers['Access-Control-Allow-Origin'] = '*'
    return response
    #return jsonify(DATA_products)
    
# енд поинт для окна показывающего все товары и квсе категории
@app.route('/all-kat-prod')
def index_all_kat_prod():
    response = make_response(render_template('all-kat-prod.html'))
    response.headers['Access-Control-Allow-Origin'] = '*'
    return response
    
# пишим энд поинт для АПИ вообще всех товаров товаров
@app.route('/api/all_products', methods=['GET'])
def get_tasks_all_products1():
    # подключаем БД
    conn = sqlite3.connect(r'./../BDB/___BDB___.db')
    cur = conn.cursor()
    # нужно обратиться к БДБ и создать список словаре который потом улетит во френт
    cur.execute("""SELECT id, 
                product_nazvanie_tovara  ,
                product_kategoriya_tovara  ,
                product_status_expert  ,
                site_ssilka_na_tovar TEXT FROM products ;""")
    all_results = cur.fetchall()
    #DATA=[]

    DATA_products = [{'id': all_results[i][0],
             'product_nazvanie_tovara': all_results[i][1], 
             'product_kategoriya_tovara': all_results[i][2],
             'product_status_expert': all_results[i][3],
             'site_ssilka_na_tovar': all_results[i][4]} for i in range(len(all_results))]
    response = make_response(jsonify(DATA_products))
    response.headers['Access-Control-Allow-Origin'] = '*'
    return response
    #return jsonify(DATA_products)
    
# сделаем хотябы перечень функций котовые еще нужно добавить
# энд поинт который принимает джейсон с категориями от эксперта
@app.route('/api/json_expert_kat', methods=['POST'])
def json_ot_experta_kategorii():
    # подключаемся к БД
    conn = sqlite3.connect(r'./../BDB/___BDB___.db')
    cur = conn.cursor()

    # получаем данные от эксперта
    request_data = request.get_json()

    # это должен быть список с категориями
    # перебираем все категории и вносим изменения в БДБ
    for item in request_data:
        id = item['id']
        name = item['name']
        roditel = item['roditel']
        status = item['status']

        # если статус "НЕОБХОДИМО УДАЛИТЬ" то даляем элемент в базе
        if status == 'НЕОБХОДИМО УДАЛИТЬ':
            # делаем запрос в БД
            cur.execute("""DELETE from kategorii where id = ?""", (id, ))
            conn.commit()
            continue

        # теперь делаем запрос по другим категориям
        # делаем запрос в БД
        cur.execute("""Update kategorii set name_kategorii = ?, roditelskaya_kategoriya =?, STATUS_expert =? where id = ?""", (name, roditel, 'СТРУКТУРА ПРОВЕРЕНА', id,))
        conn.commit()
    return '200'

# Энд поинт который принимает джейсон с товарами от эксперта
@app.route('/api/json_expert_prod', methods=['POST'])
def json_ot_experta_produts():
    # подключаемся к БД
    conn = sqlite3.connect(r'./../BDB/___BDB___.db')
    cur = conn.cursor()

    # получаем данные от эксперта
    request_data = request.get_json()

    # это должен быть список с товарами
    # перебираем все товары и вносим изменения в БДБ
    for item in request_data:
        id = item['id']
        roditel_produkt = item['product_kategoriya_tovara']

        # делаем запрос в БД
        cur.execute("""Update products set product_kategoriya_tovara = ? where id = ?""", (roditel_produkt, id,))
        conn.commit()

    return '200'
# эндпоинт для сервиса проверки страниц товаров для эксперта НУЖНА ВЕРСТКА САЙТА
@app.route('/expertiza_products', methods=['GET'])
def expertiza_products():
    # эта функция которая будет обеспечивать рендеририть сиарницы товара у эксперта для проверки
    # пока не знаю кат сделать, потомучо нет самого сайта
    return ''

# эндпоинт для проверки страниц категорий на сайте для эксперта

# функция которая формирует БД для сайта
def create_bd_syte():
    # функция создает базу данных для свйта
    puth_k_BD_syta = r'./../site application/BD.db'

    #проверяем есть ли такой файл
    if os.path.exists(puth_k_BD_syta):
        # если файл есть то удаляем его
        os.remove(puth_k_BD_syta)

    # новая база будет содержать название, описание, алиас

    # подключаемся к основной БД
    conn = sqlite3.connect(r'./../BDB/___BDB___.db')
    cur = conn.cursor()

    # создаем БД сайта
    conn_sait = sqlite3.connect(puth_k_BD_syta)
    cur_sait = conn.cursor()

    # создаем таблицу в бд с категориями
    cur_sait.execute("""CREATE TABLE IF NOT EXISTS kategorii(
           id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ,
           name_kategorii TEXT ,
           ssil_na_kategoriyu TEXT ,
           discription_kategorii TEXT ,
           ssilka_na_kartinku TEXT ,
           bread_crumbs TEXT ,
           vlojennie_kategorii JSON ,
           vlojennie_podukti JSON ,
           CEO_title TEXT ,
           CEO_keywords TEXT ,
           CEO_metoopisanie TEXT ,
           kolichestvo_tovarov INTEGER);
        """)
    conn_sait.commit()

    # получаем все категории из основной БД готовых  к публикации
    cur.execute("""SELECT name_kategorii, 
                    ssil_na_kategoriyu, 
                    discription_kategorii,
                    ssilka_na_kartinku,
                    CEO_title,
                    CEO_keywords,
                    CEO_metoopisanie,
                    kolichestvo_tovarov FROM kategorii  where STATUS_expert = ?""", ('ПРОВЕРЕНО ЭКСПЕРТОМ',))
    all_kati = cur.fetchall()

    # теперь перебираем все готовые к публикации категории и вносим их в БД для сайта
    for item in all_kati:
        # название категории
        name_kat = all_kati[0]
        ssil_na_kat = all_kati[1]
        diskripsion_kat = all_kati[2]
        ssilka_na_kartinku = all_kati[3]
        CEO_title = all_kati[4]
        CEO_keywords = all_kati[5]
        CEO_metoopisanie = all_kati[6]
        kolichestvo_tovarov = all_kati[7]

        # нужно подготовить данные для БД для сайта
        # нужно подготовить вложенные категории
        # нужно получить список дочерних категорий
        cur.execute("""SELECT name_kategorii, 
                            ssil_na_kategoriyu, 
                            discription_kategorii,
                            ssilka_na_kartinku FROM kategorii  where STATUS_expert = ?, 
                            roditelskaya_kategoriya = ?""", ('ПРОВЕРЕНО ЭКСПЕРТОМ', name_kat))
        all_doch_kat = cur.fetchall()
        # если вложенных категорий больше чем 4*7 = 28, но нужно добавлять page = 2
        # наверно нужно сделать объект
        vlojennie_kategorii = {}
        n_page = 1
        list_kat = []
        n_kat = 1
        for kat in all_doch_kat:
            if n_kat < 29:
                list_kat.append(kat[:])
                n_kat += 1
            else:
                vlojennie_kategorii[n_page] = list_kat
                list_kat = []
                n_page = 1
                n_kat = 1

        # теперь нужно сделать объект с дочерними товарами
        # получаем список товаром из главной базы данных товаров
        cur.execute("""SELECT product_nazvanie_tovara, 
                            product_opisanie_tovara, 
                            product_cena_tovara,
                            product_nalichie_tovara ,
                            product_kartinki_tovara ,
                            product_garantiya_na_tovar FROM products  where product_status_expert = ?, 
                            roditelskaya_kategoriya = ?""", ('ПРОВЕРЕНО ЭКСПЕРТОМ', name_kat))
        all_doch_produkts = cur.fetchall()

        vlojennie_podukti = {}
        n_page = 1
        list_prod = []
        n_kat = 1
        for prod in all_doch_produkts:
            if n_kat < 29:
                list_prod.append(prod[:])
                n_kat += 1
            else:
                vlojennie_podukti[n_page] = list_prod
                list_prod = []
                n_page = 1
                n_kat = 1

        # теперь нужно сформировать хлебные крошки
        # это будет список родительских категорий
        # берем ссыль на категорию разбиваем по  знаку /
        mass_bh = ssil_na_kat.split(r'/')
        # перебираем каждую вышестоящую категорию
        bread_crumbs =[]
        for item in mass_bh:
            # в хлебные крошки предадим - название - ссылку
            # делаем запрос в главную БД
            cur.execute("""SELECT name_kategorii, 
                                        ssil_na_kategoriyu FROM kategorii  where alias = ?""", (item, ))
            all_kat_bh = cur.fetchall()
            if len(all_kat_bh) > 0 :
                print('косяк в хлебных крошках')
            else:
                bread_crumbs.append(all_kat_bh)

        # теперь вносим эту категорию в малую БД сайта
        cur_sait.execute("""INSERT INTO kategorii(
                    name_kategorii ,
                    ssil_na_kategoriyu ,
                    discription_kategorii  ,
                    ssilka_na_kartinku ,
                   bread_crumbs ,
                   vlojennie_kategorii ,
                   vlojennie_podukti ,
                   CEO_title ,
                   CEO_keywords ,
                   CEO_metoopisanie ,
                   kolichestvo_tovarov) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)  """,
                         (name_kat, ssil_na_kat, diskripsion_kat, ssilka_na_kartinku, bread_crumbs, vlojennie_kategorii, vlojennie_podukti, CEO_title, CEO_keywords, CEO_metoopisanie, kolichestvo_tovarov))
        cur_sait.commit()

# функция робот которая каждый раз пробегает по товарам и проставляет статусы по всем дисциплинам
def robot_1():
    # это робот который постоянно пробегает по товарам в БД и обновляет статусы
    # подключаемся к БД
    conn = sqlite3.connect(r'./../BDB/___BDB___.db')
    cur = conn.cursor()
    # считываем все товары
    cur.execute("SELECT * FROM products;")
    all_ssil_tovari = cur.fetchall()
    # перебираем все товары
    for item in all_ssil_tovari:
        # статус товара
        status = item['product_status_expert']
        #проверяем статус
        if status == 'ПРОВЕРЕНО ЭКСПЕРТОМ':
            #  перезаписываем статус товара
            new_status = ''
def robot_2():
    # робот который прорабатывает все категории
    #    # подключаемся к БД

    conn = sqlite3.connect(r'./../BDB/___BDB___.db')
    cur = conn.cursor()
    # считываем все категории
    cur.execute("SELECT * FROM kategorii")
    all_kati = cur.fetchall()

    # проставляем алиасы
    for item in all_kati:
        item['alias'] = 'p' + str(item['id']) + r'/'
    # функция которая рекурсивно расчитывает ссылки на категории
    def alias_kati_rekursiya(name_rod_kategorii, ssil):
        # ищем в базе все категории которые имеют эту родительскую кактегорию
        cur.execute("SELECT * FROM kategorii WHERE roditelskaya_kategoriya = ?", (name_rod_kategorii,))
        all_ssil_tovari = cur.fetchall()

        if all_ssil_tovari is not None:
            # перебираем всю выборку
            for i in all_ssil_tovari:
                # ссылка на вложенную категорию
                ssil_tekusv_kat = ssil + i['alias'] + r'/'

                # запускаем рекурсию
                alias_kati_rekursiya(i['name_kategorii'], ssil_tekusv_kat)

    alias_kati_rekursiya('Каталог', r'/')

    # ссылки на категории сформировали теперь наверно сформируем базу данных для сайта для категорий
    # перебираем все категории


#   
    
if __name__ == "__main__":
    app.run(debug=True)