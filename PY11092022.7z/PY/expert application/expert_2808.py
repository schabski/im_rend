from flask import Flask, jsonify, render_template, make_response, url_for
import sqlite3



app = Flask(__name__)
#from app import views


@app.route('/')
@app.route('/index')
def index():
    response = make_response(render_template('index.html'))
    response.headers['Access-Control-Allow-Origin'] = '*'
    return response
    #return render_template("index.html")

@app.route('/api/cat', methods=['GET'])
def get_tasks():
    # подключаем БД
    conn = sqlite3.connect(r'./../BDB/___BDB___.db')
    cur = conn.cursor()
    # нужно обратиться к БДБ и создать список словаре который потом улетит во френт
    cur.execute("SELECT id, name_kategorii, roditelskaya_kategoriya, STATUS_expert FROM kategorii;")
    all_results = cur.fetchall()
    #DATA=[]

    DATA = [{'id': all_results[i][0],'name': all_results[i][1], 'roditel': all_results[i][2], 'status': all_results[i][3]} for i in range(len(all_results))]
    
    response = make_response(jsonify(DATA))
    response.headers['Access-Control-Allow-Origin'] = '*'
    return response
    #return jsonify(DATA)

# пишим энд поинт для АПИ новых товаров
@app.route('/api/new_products', methods=['GET'])
def get_tasks_products():
    # подключаем БД
    conn = sqlite3.connect(r'./../BDB/___BDB___.db')
    cur = conn.cursor()
    # нужно обратиться к БДБ и создать список словаре который потом улетит во френт
    cur.execute("""SELECT id, 
                product_nazvanie_tovara  ,
                product_kategoriya_tovara  ,
                product_artikul_tovara  ,
                product_kartinki_tovara  ,
                product_dokumenti_tovara  ,
                product_status_expert  ,
                provider_name  ,
                provider_ssilka_na_tovar  , 
                provider_nazvanie_tovara  ,
                provider_kategoriya_tovara  ,
                provider_cena_tovara  ,
                provider_nalichie_tovara  ,
                provider_artikul_tovara FROM products WHERE product_status_expert='НЕОБХОДИМО ОПРЕДЕЛИТЬ КАТЕГОРИЮ ТОВАРА';""")
    all_results = cur.fetchall()
    #DATA=[]

    DATA_products = [{'id': all_results[i][0],
             'product_nazvanie_tovara': all_results[i][1], 
             'product_kategoriya_tovara': all_results[i][2], 
             'product_artikul_tovara': all_results[i][3], 
             'product_kartinki_tovara': all_results[i][4], 
             'product_dokumenti_tovara': all_results[i][5], 
             'product_status_expert': all_results[i][6], 
             'provider_name': all_results[i][7], 
             'provider_ssilka_na_tovar': all_results[i][8], 
             'provider_nazvanie_tovara': all_results[i][9], 
             'provider_kategoriya_tovara': all_results[i][10], 
             'provider_cena_tovara': all_results[i][11], 
             'provider_nalichie_tovara': all_results[i][12], 
             'provider_artikul_tovara': all_results[i][13]} for i in range(len(all_results))]
    response = make_response(jsonify(DATA_products))
    response.headers['Access-Control-Allow-Origin'] = '*'
    return response
    #return jsonify(DATA_products)
    
# енд поинт для окна показывающего все товары и квсе категории
@app.route('/all-kat-prod')
def index_all_kat_prod():
    response = make_response(render_template('all-kat-prod.html'))
    response.headers['Access-Control-Allow-Origin'] = '*'
    return response
    
# пишим энд поинт для АПИ вообще всех товаров товаров
@app.route('/api/all_products', methods=['GET'])
def get_tasks_all_products1():
    # подключаем БД
    conn = sqlite3.connect(r'./../BDB/___BDB___.db')
    cur = conn.cursor()
    # нужно обратиться к БДБ и создать список словаре который потом улетит во френт
    cur.execute("""SELECT id, 
                product_nazvanie_tovara  ,
                product_kategoriya_tovara  ,
                product_status_expert  ,
                site_ssilka_na_tovar TEXT FROM products ;""")
    all_results = cur.fetchall()
    #DATA=[]

    DATA_products = [{'id': all_results[i][0],
             'product_nazvanie_tovara': all_results[i][1], 
             'product_kategoriya_tovara': all_results[i][2],
             'product_status_expert': all_results[i][3],
             'site_ssilka_na_tovar': all_results[i][4]} for i in range(len(all_results))]
    response = make_response(jsonify(DATA_products))
    response.headers['Access-Control-Allow-Origin'] = '*'
    return response
    #return jsonify(DATA_products)
    
    
    
if __name__ == "__main__":
    app.run(debug=True)