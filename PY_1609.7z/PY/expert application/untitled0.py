# -*- coding: utf-8 -*-
"""
Created on Wed Sep  7 11:42:23 2022

@author: Zhabskii_AV
"""

print(123)