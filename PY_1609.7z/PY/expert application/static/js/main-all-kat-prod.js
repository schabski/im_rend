document.addEventListener("DOMContentLoaded", () =>{
  // начинаем делать интерфейс эксперта который будет администрировать интернет магазин
  // дом загрузили теперь нужно получить джейсон со структурой категорий от сервака
  console.log('sgrg');


  // задаем в переменную цвет выбранной категории
  let cvet_vibrannoi_kategorii = 'PaleTurquoise';
  // переменная для выбранной категории
  let vibrannaya_kategoriya ='';
  let vibrannaii_tovar ='';

  //* теперь скачиваем биг массив по всем товарам
  // переменная для массива данных 
  let dataRespone_all_products
  async function zapros_products() {
    let respone = await fetch ('http://127.0.0.1:5000/api/all_products');
    dataRespone_all_products = await respone.json();
    zapros_kategorii(dataRespone_all_products);
  }


  // переменная для массива данных категорий
  let dataRespone_all_kategorii
  async function zapros_kategorii() {
    let respone = await fetch ('http://127.0.0.1:5000/api/cat');
    dataRespone_all_kategorii = await respone.json();
    make_derevo_kategorii_i_tovarov('Каталог', ul_katalog);
  }
  

  // теперь методом рекурсии строим дерево категорий и товаров
  // самая первая категория - это каталог
  //добавляем UL
  let ul_katalog = document.createElement('span');
  ul_katalog.innerText = 'Каталог';
  

  let derevo = document.getElementById('derevo');
  derevo.append(ul_katalog);


  let n_urovnia = 1
  function make_derevo_kategorii_i_tovarov(name_kategorii, roditel) {

    // ищем вложенные категории
    // теперь проверяем есть ли дочернии категории
    let flag_dochki = false
    let doch_kategorii = []
    for (key of dataRespone_all_kategorii) {
      if (key.roditel === name_kategorii) {
        doch_kategorii.push(key.name);
        flag_dochki = true;
      }
    }



    // если есть вложенные категории
    if (flag_dochki) {
      // попробуем добавить + к родителю
      roditel.classList.add('minus');

      
      // если дочерние категории есть то создаем элемент <ul>
      let ul_element = document.createElement('ul');
      roditel.append(ul_element);

      // попробуем повесить обработчик событий на клик по родителю
      roditel.addEventListener('click', (event) => {
        let nam_kat
        if (roditel.innerText.indexOf('\n') > 0) {
          nam_kat = roditel.innerText.slice(0, roditel.innerText.indexOf('\n'))
        } else {
          nam_kat = roditel.innerText
        }
        let nam_event_kat
        if (event.target.innerText.indexOf('\n') > 0) {
          nam_event_kat = event.target.innerText.slice(0, event.target.innerText.indexOf('\n'))
        } else {
          nam_event_kat = event.target.innerText
        }
        //alert(nam_event_kat)

        if (nam_event_kat === nam_kat) {
          vibrannaya_kategoriya = nam_event_kat

          if (ul_element.style.display === "none") {
            ul_element.style = "display:block";
            // рисуем минус на родителе
            roditel.classList.add('minus');
            roditel.classList.remove('plus');
          } else {
            ul_element.style = "display:none";
            // рисуем минус на родителе
            roditel.classList.remove('minus');
            roditel.classList.add('plus');
          }
        }
        snyatie_cvetovogo_videleniya()

      })

      // ул и обработчик сделали теперь пробегаемся по всем дочкам и публикуем их
      for (item of doch_kategorii) {
        // поробуем проверить если эта категория со статусом НЕОБХОДИМО Удалить то пропускаем эту категорию
        let flag_status = true
        for (key of dataRespone) {
          if (key.name === item) {
            if (key.status === 'НЕОБХОДИМО УДАЛИТЬ') {
              flag_status = false
            }
          }
        }
        // если эта категория не имеет статус к удалению поэтому ее можно публиковать
        if (flag_status) {
          // создаем элемент <li>
          let li_element = document.createElement('li');
          li_element.textContent = item;

          //добавляем класс с цветом текста категории
          li_element.classList.add('derevo-kat-text');


          // вешаем обработчик клика
          li_element.addEventListener('click', (event) => {
            if (event.target.innerText === li_element.innerText) {
              // получаен наименование выбранной категории
               let name_kat = ''
              if (event.target.innerText.indexOf('\n') > 0) {
                name_kat = event.target.innerText.slice(0, event.target.innerText.indexOf('\n'));
              } else {
                name_kat = event.target.innerText;
              }
              vibrannaya_kategoriya = name_kat;
            }
            snyatie_cvetovogo_videleniya()
          })

          // вешаем обработчик наведение курсора
          li_element.addEventListener('mouseover', (event) => {
            if (event.target.innerText === li_element.innerText) {
              li_element.style.background  = 'Lime';
            }
          })

          // вешаем обработчик снятия наведение курсора
          li_element.addEventListener('mouseout', (event) => {
            if (vibrannaya_kategoriya === event.target.innerText) {
              li_element.style.background  = 'PaleTurquoise';
            } else {
              li_element.style.background  = 'none';
            }
            snyatie_cvetovogo_videleniya()

          })

          // добавляем категорию в список
          ul_element.append(li_element);

          // запускаем рекурсию с этой категорией
          make_derevo_kategorii_i_tovarov(item, li_element)
        }

      }
    }


    
    // добавляем товары в категорию
    // преребираем все товары
    let flag_prod = false

    for (key of dataRespone_all_products) {
      if (key.product_kategoriya_tovara === item) {
        flag_prod = true;
      }
    }

    // если товары в этой категории есть то выстраиваем дерево товаров
    // перебираем все товары
    // 
    if (flag_prod) {
      let ul_element_prod = document.createElement('ul');
      roditel.append(ul_element_prod);

      for (key of dataRespone_all_products) {
        if (key.product_kategoriya_tovara === item) {
          let li_prod = document.createElement('li');
          li_prod.textContent = key.product_nazvanie_tovara;
          li_prod.classList.add('derevo-tovar-text');
          ul_element_prod.append(li_prod);

          // теперь вешаем обработчики на товар 
          // вешаем обработчик наведение курсора
          li_prod.addEventListener('mouseover', (event) => {
            if (event.target.innerText === li_prod.innerText) {
              li_prod.style.background  = 'Salmon';
            }
          })

          // вешаем обработчик снятия наведение курсора
          li_prod.addEventListener('mouseout', (event) => {
            if (vibrannaii_tovar === event.target.innerText) {
              li_prod.style.background  = 'DarkCyan';
            } else {
              li_prod.style.background  = 'none';
            }
            snyatie_cvetovogo_videleniya()

          })

          // вешаем обработчик по клику на товар
          li_prod.addEventListener('click', (event) => {
            vibrannaii_tovar = event.target.innerText;
          })

        }
      }

    }


  }


  zapros_products()

  // сделаем функцию которая снимает цветовое выделение с дерева категорий
  // эта функция будет отрабатывать события по выбору категории
  function snyatie_cvetovogo_videleniya() {
    let vse_kati = derevo.getElementsByTagName('li')
    for (kat of vse_kati) {
      let sravnen = '';

      if (kat.innerText.indexOf('\n') > 0) {
        sravnen = kat.innerText.slice(0, kat.innerText.indexOf('\n'))
      } else {
        sravnen = kat.innerText;
      }


      // подготавливаем имя товара
      let sravnen_prod = '';
      if (kat.innerText.indexOf('\n') > 0) {
        sravnen_prod = kat.innerText.slice(0, kat.innerText.indexOf('\n'))
      } else {
        sravnen_prod = kat.innerText;
      }


      if (sravnen === vibrannaya_kategoriya) {
        kat.style.background  = 'PaleTurquoise';
      } else if (sravnen_prod === vibrannaii_tovar) {
        kat.style.background  = 'DarkCyan';
      } else {
        kat.style.background  = 'none';
      }



    }

    // вставляем наименование выбранной категории
    let text_vibrannoi_kategorii = document.getElementById('vibor-kat');
    text_vibrannoi_kategorii.innerText = vibrannaya_kategoriya;


    // вставляем наименование выбранного товара
    let text_vibrannjgo_tovara = document.getElementById('vibor-prod');
    text_vibrannjgo_tovara.innerText = vibrannaii_tovar;
  }



  // теперь делаем функционал кнопок
  // кнопка удалить категорию
  let button_remove_kategoriyu = document.getElementById('remove-kategoriyu');
  // наименование выбранной категории
  let text_vibrannoi_kategorii = document.getElementById('vibor-kat');
  vibrannaya_kategoriya = text_vibrannoi_kategorii.innerText;
  // вешаем обработчик на кнопу удалить каегорию
  button_remove_kategoriyu.addEventListener('click', (event) => {
    if (vibrannaya_kategoriya == '')  {
      return
    }
    // проверяем чтоб вложенных категоррий не было
    let flag_dochki = false;
    for (key of dataRespone) {
      if (key.roditel === vibrannaya_kategoriya && key.status !== 'НЕОБХОДИМО УДАЛИТЬ') {
        flag_dochki = true;
      }
    }

    if (flag_dochki) {
      alert("Пока нельзя удалить категорию у которой есть дочерние категории")
      return
    }

    //присваиваем статус категории 
    for (key of dataRespone) {
      if (key.name === vibrannaya_kategoriya) {
        key.status = 'НЕОБХОДИМО УДАЛИТЬ'
      }
    }
    vibrannaya_kategoriya = ''
    // перестраиваем дерево
    ul_katalog.innerHTML = ''
    ul_katalog.innerText = 'Каталог';

    make_derevo_kategorii('Каталог', ul_katalog)

  })


  // далее пишем код для кнопки переименовать категорию
  // кнопка удалить категорию
  let button_rename_kategoriyu = document.getElementById('rename-kategoriyu');
  // вешаем обработчик на кнопу
  button_rename_kategoriyu.addEventListener('click', (event) => {
    // получаем новое наименование
    if (vibrannaya_kategoriya == '')  {
      return
    }
    let new_name = prompt('Новое наименование категории');
    
    // 1 проверяем чтобы не было 2 одинаковых категорий
    // перебираем массив с категориями
    for (key of dataRespone_all_kategorii) {
      if (key.name === new_name) {
        alert('Такая категория уже есть!');
        return;
      }
    }

    if (new_name !== '' && new_name !== null)  {

      //присваиваем статус категории 
      for (key of dataRespone) {
        if (key.name === vibrannaya_kategoriya) {
          key.name = new_name
        }
      }

      // далее пробегаемся вложенные категории
      for (key of dataRespone) {
        if (key.roditel === vibrannaya_kategoriya) {
          key.roditel = new_name
        }
      }

      vibrannaya_kategoriya = new_name

      // перестраиваем дерево
      ul_katalog.innerHTML = ''
      ul_katalog.innerText = 'Каталог';
      make_derevo_kategorii('Каталог', ul_katalog)
      snyatie_cvetovogo_videleniya()


    }
  })

  // вешаем обработчик на кнопку добавления вложенной категории
  let button_add_kategoriyu = document.getElementById('add-kategoriyu');
  // вешаем обработчик на кнопу
  button_add_kategoriyu.addEventListener('click', (event) => {
    if (vibrannaya_kategoriya !== '')  {
      
      // получаем новое наименование
      let new_name = prompt('Dведи наименование новой вложенной категории');
      
      // 1 проверяем чтобы не было 2 одинаковых категорий
      // перебираем массив с категориями
      for (key of dataRespone_all_kategorii) {
        if (key.name === new_name) {
          alert('Такая категория уже есть!');
          return;
        }
      }

      if (new_name !== '' && new_name !== null)  {
        // создаем новый объект 
        new_kat ={}
        new_kat.id = ''
        new_kat.name = new_name
        new_kat.roditel = vibrannaya_kategoriya
        new_kat.status = 'НЕОБХОДИМО ДОБАВИТЬ'

        dataRespone.push(new_kat)

        vibrannaya_kategoriya = new_name

        // перестраиваем дерево
        ul_katalog.innerHTML = ''
        ul_katalog.innerText = 'Каталог';
        make_derevo_kategorii('Каталог', ul_katalog)
        snyatie_cvetovogo_videleniya()
      }
    }
  })

  // вешаем обработчик на кнопку перемещения товара в выбранную категорию
  let button_move_prod = document.getElementById('add-rod-kategoriyu');
  // вешаем обработчик на кнопу
  button_move_prod.addEventListener('click', (event) => {
    if (vibrannaya_kategoriya !== '' && vibrannaii_tovar !== '')  {
      
      // перебираем все товары, находим наш и меняем в нем категорию
      for (key of dataRespone_all_products) {
        if (key.product_nazvanie_tovara === vibrannaii_tovar) {
          key.product_kategoriya_tovara = vibrannaya_kategoriya;
        }
      }


        // перестраиваем дерево
        ul_katalog.innerHTML = ''
        ul_katalog.innerText = 'Каталог';
        make_derevo_kategorii_i_tovarov('Каталог', ul_katalog)
        snyatie_cvetovogo_videleniya()
      
    }
  })

  // добавляем функцию проверки категорий и товаров пред отправкой на сервак
  // 1 проверяем чтобы не было 2 одинаковых категорий
  // 2 проверяем что бы у товаров были категории которые есть в массиве. Но это не точно потом додумаю
  // 3 

  function proverka_kategori() {
    // 1 проверяем чтобы не было 2 одинаковых категорий
    // перебираем массив с категориями
    for (key of dataRespone_all_kategorii) {
      let name_kat = key.name;
      let count_kat;
      count_kat = 0;
      for (key2 of dataRespone_all_kategorii) {
        if (key2.name === name_kat) {
          count_kat = count_kat + 1;
        }
      }
      if (count_kat > 0) {
        alert('Какаято категория задублирована');
        return false;
      }
    }
    return true;
  }

  // делаем функцию обработчик на кнопку отпуливания массивов с категориями и товарами на сервак
  // сама кнопка
  let button_otprav_data_na_servak = document.getElementById('otpr-na-server');

  // обработчик события клика на кнопке
  button_otprav_data_na_servak.addEventListener('click', (event) => {
    if (proverka_kategori()) {
      return
    }

    // Отправляем категории
    let xhr = new XMLHttpRequest();

    let body = JSON.stringify(dataRespone_all_kategorii);
    xhr.open("POST", "/expert_kat" , true);
    
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    xhr.onreadystatechange = function() {
    // сдесь что-то делаем с ответом от сервера

    }
    xhr.send(body);



    // Отправляем товары
    let xhr_prod = new XMLHttpRequest();

    let body_prod = JSON.stringify(dataRespone_all_products);
    xhr_prod.open("POST", "/expert_prod" , true);
    
    xhr_prod.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    xhr_prod.onreadystatechange = function() {
    // сдесь что-то делаем с ответом от сервера
    
    }
    xhr_prod.send(body);




  })


})