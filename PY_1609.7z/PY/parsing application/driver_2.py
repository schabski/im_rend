# Здесь я попробую написать код для парсинга сайтов поставщиков

import requests
from bs4 import BeautifulSoup
import sqlite3

#Выделяем все по функциям
def voll_kat_1_urovnia():
    print("Поехали. Собираем категории 1 уровня ВОЛЛ")


    # Создаем таблицу в БД
    cur.execute("""CREATE TABLE IF NOT EXISTS voll_kategorii_1(
           name_kategorii TEXT ,
           ssil_kategorii TEXT);
        """)
    conn.commit()

    # делаем запрос на сайт
    url = r'https://voll.ru/product'
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'lxml')
    quotes = soup.find_all('li', class_='child')

    for link in quotes:
        # print(link)

        ss = link.find_all('a', class_='')
        ss2 = r'https://voll.ru' + ss[0]['href']

        # проверяем есть ли такая категория в таблице
        cur.execute("SELECT * FROM voll_kategorii_1 WHERE ssil_kategorii  = ?", (ss2,))
        if cur.fetchone() is None:
            # если категории раньше не было
            cur.execute("""INSERT INTO voll_kategorii_1 VALUES(?, ?);""", (link.text, ss2))
            conn.commit()

def voll_kat_2_urovnia():
    print("Поехали. Собираем категории 2 уровня ВОЛЛ")

    # Создаем таблицу в БД
    cur.execute("""CREATE TABLE IF NOT EXISTS voll_kategorii_1(
           name_kategorii_2 TEXT ,
           ssil_kategorii_2 TEXT);
        """)
    conn.commit()

    #нужно перебрать все категории 1 уровня и найти в них ссылки на категории 2 уровня

    #Все категории 1 уровня
    cur.execute("SELECT ssil_kategorii FROM voll_kategorii_1;")
    all_kategorii_1_urovnia = cur.fetchall()

    for item in all_kategorii_1_urovnia:
        #теперь загружаем каждую категорию 1 уровня
        kat_2_ssil = item[0]

        # делаем запрос на сайт
        url = kat_2_ssil
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'lxml')

        # страницу загрузили - дальше ищем теги
        quotes = soup.find_all('li', class_='active')

        for link in quotes:
            # print(link)

            ss = link.find_all('a', class_='')
            ss2 = r'https://voll.ru' + ss[0]['href']

            # проверяем есть ли такая категория в таблице
            cur.execute("SELECT * FROM voll_kategorii_1 WHERE ssil_kategorii_2  = ?", (ss2,))
            if cur.fetchone() is None:
                # если категории раньше не было
                cur.execute("""INSERT INTO ssil_kategorii_2 VALUES(?, ?);""", (link.text, ss2))
                conn.commit()

def voll_tovari():
    print("Поехали. Собираем товары ВОЛЛ")
    # нужно занрузить категории 1 и второго уровня и найти все ссылки на товары
    # Создаем стобцы в БД
    cur.execute("""CREATE TABLE IF NOT EXISTS voll_kategorii_1(
           ssilka_na_tovar TEXT);
        """)
    conn.commit()

    # ссылки на категории 1 уровня
    #Все категории 1 уровня
    cur.execute("SELECT ssil_kategorii FROM voll_kategorii_1;")
    all_kategorii_1_urovnia = cur.fetchall()

    #Все категории 2 уровня
    cur.execute("SELECT ssil_kategorii_2 FROM voll_kategorii_1;")
    all_kategorii_2_urovnia = cur.fetchall()

    # вообще все категории
    all_kat =all_kategorii_1_urovnia.append(all_kategorii_2_urovnia)

    #перебираем все категории и ищем ссылки на товары
    for item in all_kat:
        #теперь загружаем каждую категорию 1 уровня
        kat_ssil = item[0]

        # делаем запрос на сайт
        url = kat_ssil
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'lxml')

        # страницу загрузили - дальше ищем теги
        quotes = soup.find_all('div', class_='title')

        for link in quotes:
            # print(link)

            ss = link.find_all('a', class_='dark-color')
            ss2 = r'https://voll.ru' + ss[0]['href']

            # проверяем есть ли такая категория в таблице
            cur.execute("SELECT * FROM voll_kategorii_1 WHERE ssilka_na_tovar  = ?", (ss2,))
            if cur.fetchone() is None:
                # если категории раньше не было
                cur.execute("""INSERT INTO ssilka_na_tovar VALUES(?);""", (ss2,))
                conn.commit()

def voll_dannie_o_tovarah():
    # сдесь скачиваем данные о товарах
    # создаем таблицу с товарами
    cur.execute("""CREATE TABLE IF NOT EXISTS voll_tovari(
           ssilka_na_tovar TEXT ,
           nazvanie_tovara TEXT ,
           opisanie_tovara TEXT ,
           kategoriya_tovara TEXT ,
           cena_tovara TEXT ,
           nalichie_tovara TEXT ,
           artikul_tovara TEXT ,
           kartinki_tovara TEXT ,
           dokumenti_tovara TEXT ,
           status_tovara_dla_BDB TEXT ,
           garantiya_na_tovar TEXT);
        """)
    conn.commit()


    # получаем список ссылок на товары
    cur.execute("SELECT * FROM ssilka_na_tovar;")
    all_ssil_tovari = cur.fetchall()
    for item in all_ssil_tovari:
        #теперь загружаем каждую категорию 1 уровня
        tovar_ssil = item[0]
        # делаем запрос на сайт
        url = tovar_ssil
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'lxml')

        # страницу загрузили - дальше ищем теги
        # ищем название товара
        name_tovara = soup.find_all('h1', class_='shares')[0]

        # считываем описание товара
        # сначало описание
        opisanie_tovara = soup.find_all('div', class_='content')[0]
        # характеристики
        opisanie_tovara += soup.find_all('div', class_='char-wrapp')[0]

        # полуаем категорию товара
        kategoriya_1 = soup.find_all('li', itemprop_='itemListElement')[-2].text

        # получаем  цену товара
        cena_tovara = soup.find_all('span', itemprop_='price')[0].text

        # получаем наличие товара
        nalichie_tovara = soup.find_all('div', class_='status-icon instock')[0].text

        # получаем артикул товара
        art = soup.find_all('div', class_='article')[0]
        artikul = art.find_all('span', class_='')[0].text

        # получаем список картинок
        kartinki = soup.find_all('li', class_='bx-clone')
        kartinki_tovara = [r'https://voll.ru' + kartinki[i]['src'] for i in range(len(kartinki))]

        # получаем список документов
        doki = soup.find_all('div', class_='inner-wrapper')
        doki_2 = [doki[i].find_all('a', class_='dark-color text') for i in range(len(doki))]
        dokumenti_tovara = [r'https://voll.ru' + doki_2[i]['href'] for i in range(len(doki_2))]

        #статус товара
        status_tovara = 'В процессе парсинга'

        #получаем срок гарантии на товар
        garantiya_na_tovar = soup.find_all('a', class_='garanty-link')[0].text

        # все данные о товаре считали

        # проверяем есть ли такой товар в БД в таблице
        cur.execute("SELECT artikul_tovara FROM voll_tovari WHERE artikul_tovara  = ?", (artikul,))
        if cur.fetchone() is None:
            # если товара нет раньше то добавляем его в БД
            cur.execute("""INSERT INTO voll_tovari VALUES(?);""", (artikul,))
            conn.commit()


if __name__ == "__main__":
    # Создадим базу данных категорий 1 уровня
    conn = sqlite3.connect('bd_parser.db')
    cur = conn.cursor()


    #запускаем сбор категорий первого уровня
    voll_kat_1_urovnia()

    #запускаем сбор категорий второго уровня
    voll_kat_2_urovnia()

    # теперь пришло время скачать инфу о товарах. Это самое трудное
    # получаем таблицу со всеми товарами
    voll_tovari()

    # теперь загружаем страничку каждого товара и скачиваем данные о товаре
    voll_dannie_o_tovarah()




    cur.execute("SELECT ssil_kategorii FROM voll_kategorii_1;")
    all_results = cur.fetchall()
    print(all_results)

